const express = require('express');
const path = require('path');
const hbs = require('hbs');

const app = express();

app.set('views', './src/views');
hbs.registerPartials(path.join(__dirname, 'views/partials'));
app.set('view engine', 'hbs');

app.get('/main', (req, res) => {
    res.render('main', {
        pageTitle: "Strona główna"
    })
});

app.get('/turtleaerodynamics', (req, res) => {
    res.render('turtleaerodynamics', {
        pageTitle: "Rzułf"
    })
});

app.get('/tak', (req, res) => {
    res.render('tak', {
        pageTitle: "pajpierz"
    })
});

app.get('/about', (req, res) => {
    res.render('about', {
        pageTitle: "O mnie"
    })
});

app.get('/contact', (req, res) => {
    res.render('contact', {
        pageTitle: "Kontakt"
    })
});

app.listen(5000, () => {
    console.log("Serwer dzaiła!")
});